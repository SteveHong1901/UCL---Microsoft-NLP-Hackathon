import os

print(os.path.exists('Audio/temp.wav'))